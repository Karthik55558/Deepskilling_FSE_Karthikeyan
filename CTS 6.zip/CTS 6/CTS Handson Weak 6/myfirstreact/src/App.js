import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <center>
    <h1>Welcome the first session of React</h1>
    </center>
  );
}

export default App;
