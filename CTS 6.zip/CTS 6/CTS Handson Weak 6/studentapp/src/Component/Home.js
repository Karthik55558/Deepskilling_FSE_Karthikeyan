import React,{Component}from'react';
 class Home extends Component{
    render(){
        return(
            <center>
        <div>
        <h3> Welcome to the Home page of Student Managment</h3>
        </div>
        </center>
        );
    }
}

export default Home;