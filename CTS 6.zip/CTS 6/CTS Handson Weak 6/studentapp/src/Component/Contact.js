import React, { Component } from "react";

class Contact extends Component {
  render() {
    return (
        <center>
      <div>
        <h3>Welcome to the home page of student Management portal</h3>
      </div>
      </center>
    );
  }
}

export default Contact; // ✅ This must be there
