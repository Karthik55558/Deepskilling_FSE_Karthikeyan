import React, { Component } from "react";

class About extends Component {
  render() {
    return (
        <center>
      <div>
        <h3>Welcome to the Home page</h3>
      </div>
      </center>
    );
  }
}

export default About; // ✅ This line is very important
