import logo from './logo.svg';
import './App.css';
import  CalculateScore  from './Component/CalculateScore';
function App() {
  return (
    <div>
    <CalculateScore Name={"Steeve"}
    School = {"Venkateshwara School"}
    total = {500}
    goal={5}
    />
    </div>
  );
}

export default App;
