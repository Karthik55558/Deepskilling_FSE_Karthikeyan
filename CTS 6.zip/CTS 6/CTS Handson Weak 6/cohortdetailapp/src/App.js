import logo from './logo.svg';
import './App.css';
import React from 'react';
import CohortDetails from './CohortDetails';

function App() {
  return (
    <div>
      <CohortDetails title="React Bootcamp" trainer="Alice" status="ongoing" />
      <CohortDetails title="Node Masterclass" trainer="Bob" status="completed" />
    </div>
  );
}

export default App;
