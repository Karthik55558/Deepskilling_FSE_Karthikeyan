package com.cognizant.spring_learn2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringLearn2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
