package com.cognizant.spring_learn2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringLearn2Application {
    public static void main(String[] args) {
        SpringApplication.run(SpringLearn2Application.class, args);
    }
}
