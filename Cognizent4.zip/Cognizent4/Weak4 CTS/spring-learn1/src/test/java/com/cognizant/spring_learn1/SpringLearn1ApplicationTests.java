package com.cognizant.spring_learn1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringLearn1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
