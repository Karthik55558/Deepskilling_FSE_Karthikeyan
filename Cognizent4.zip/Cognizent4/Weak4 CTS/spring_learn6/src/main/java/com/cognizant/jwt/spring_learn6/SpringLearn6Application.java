package com.cognizant.jwt.spring_learn6;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringLearn6Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringLearn6Application.class, args);
	}

}
