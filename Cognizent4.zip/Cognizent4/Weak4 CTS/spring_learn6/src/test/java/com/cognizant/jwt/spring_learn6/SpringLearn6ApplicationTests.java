package com.cognizant.jwt.spring_learn6;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringLearn6ApplicationTests {

	@Test
	void contextLoads() {
	}

}
