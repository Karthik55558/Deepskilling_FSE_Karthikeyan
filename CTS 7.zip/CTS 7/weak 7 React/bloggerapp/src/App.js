import React, { useState } from 'react';
import BookDetails from './BookDetails';
import BlogDetails from './BlogDetails';
import CourseDetails from './CourseDetails';

function App() {
  const [show, setShow] = useState("books"); // possible: books, blogs, courses

  return (
    <div style={{ padding: '30px', fontFamily: 'Arial' }}>
      <h1>Blogger Application</h1>

      {/* Buttons for switching views */}
      <button onClick={() => setShow("books")}>Show Books</button>
      <button onClick={() => setShow("blogs")}>Show Blogs</button>
      <button onClick={() => setShow("courses")}>Show Courses</button>

      <hr />

      {/* CONDITIONAL RENDERING (3 WAYS SHOWN BELOW) */}

      {/* Way 1: if-else like ternary */}
      {show === "books" ? <BookDetails /> : null}

      {/* Way 2: Logical && */}
      {show === "blogs" && <BlogDetails />}

      {/* Way 3: Switch style using element variable */}
      {(() => {
        if (show === "courses") {
          return <CourseDetails />;
        }
        return null;
      })()}
    </div>
  );
}

export default App;
