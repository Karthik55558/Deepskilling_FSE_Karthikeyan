import React from 'react';

const BookDetails = () => {
  const books = [
    { id: 1, title: "React in Action", author: "Mark T." },
    { id: 2, title: "JavaScript: The Good Parts", author: "Douglas Crockford" }
  ];

  return (
    <div>
      <h3>Book List:</h3>
      <ul>
        {books.map(book => (
          <li key={book.id}>
            {book.title} by {book.author}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default BookDetails;
