import React from 'react';

const BlogDetails = () => {
  const blogs = [
    { id: 1, title: "Understanding React Keys" },
    { id: 2, title: "Conditional Rendering in React" }
  ];

  return (
    <div>
      <h3>Blog List:</h3>
      <ul>
        {blogs.map(blog => (
          <li key={blog.id}>{blog.title}</li>
        ))}
      </ul>
    </div>
  );
};

export default BlogDetails;
