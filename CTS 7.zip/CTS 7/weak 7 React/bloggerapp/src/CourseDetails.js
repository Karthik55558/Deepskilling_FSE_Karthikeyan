import React from 'react';

const CourseDetails = () => {
  const courses = [
    { id: 1, name: "React Basics" },
    { id: 2, name: "Advanced JavaScript" }
  ];

  return (
    <div>
      <h3>Course List:</h3>
      <ul>
        {courses.map(course => (
          <li key={course.id}>{course.name}</li>
        ))}
      </ul>
    </div>
  );
};

export default CourseDetails;
