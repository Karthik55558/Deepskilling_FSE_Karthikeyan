import React from 'react';
import logo from './logo.svg';
import officeImage from './assets/img1.jpg';
import './App.css';

function App() {
  const heading = "Office Space Rental Details";

  const officeList = [
    { name: "Office A", rent: 75000, address: "Chennai" },
    { name: "Office B", rent: 50000, address: "Mumbai" },
    { name: "Office C", rent: 60000, address: "Delhi" },
    { name: "Office D", rent: 85000, address: "Bangalore" },
    { name: "Office E", rent: 45000, address: "Hyderabad" }
  ];

 // const officeImage = "https://via.placeholder.com/300x150?text=Office+Image"; // sample image

  return (
    <div style={{ padding: "20px", fontFamily: "Arial" }}>
      <h1>{heading}</h1>
      <div>
      <img src={officeImage} alt='Office image' width="300" height="150"/>
      </div>
      <h2>Available Office Spaces:</h2>
      <ul>
        {officeList.map((office, index) => (
          <li key={index} style={{ marginBottom: "10px" }}>
            <strong>Name:</strong> {office.name}<br />
            <strong>Rent:</strong>{" "}
            <span style={{ color: office.rent < 60000 ? "red" : "green" }}>
              ₹{office.rent}
            </span><br />
            <strong>Address:</strong> {office.address}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default App;