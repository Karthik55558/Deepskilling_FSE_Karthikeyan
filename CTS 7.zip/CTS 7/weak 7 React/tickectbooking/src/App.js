import React, { Component } from 'react';

// Guest Component
function GuestPage() {
  return (
    <div>
      <h2>Welcome Guest!</h2>
      <p>You can browse flight details but need to log in to book tickets.</p>
    </div>
  );
}

// User Component
function UserPage() {
  return (
    <div>
      <h2>Welcome Back, User!</h2>
      <p>You can now book your flight tickets.</p>
    </div>
  );
}

class App extends Component {
  constructor() {
    super();
    this.state = {
      isLoggedIn: false
    };
  }

  // Toggle login state
  handleLogin = () => {
    this.setState({ isLoggedIn: true });
  };

  handleLogout = () => {
    this.setState({ isLoggedIn: false });
  };

  render() {
    // Element variable for conditional rendering
    let pageContent;

    if (this.state.isLoggedIn) {
      pageContent = <UserPage />;
    } else {
      pageContent = <GuestPage />;
    }

    return (
      <div style={{ textAlign: 'center', marginTop: '50px' }}>
        <h1>Ticket Booking App</h1>

        {/* Render login/logout buttons conditionally */}
        {this.state.isLoggedIn ? (
          <button onClick={this.handleLogout}>Logout</button>
        ) : (
          <button onClick={this.handleLogin}>Login</button>
        )}

        <hr />

        {/* Display the appropriate page based on login state */}
        {pageContent}
      </div>
    );
  }
}

export default App;
