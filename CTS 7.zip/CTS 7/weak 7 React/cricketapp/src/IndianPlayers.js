import React from 'react';

const IndianPlayers = () => {
  const oddTeam = ["Virat", "Dhoni", "Pant", "Hardik", "Shami"];
  const evenTeam = ["Rohit", "Rahul", "Ashwin", "Bumrah", "Surya"];

  // Destructuring
  const [player1, player2, ...restOdd] = oddTeam;
  const [e1, e2, ...restEven] = evenTeam;

  // Merging arrays
  const T20players = ["Kohli", "Rohit"];
  const RanjiTrophyPlayers = ["Jadeja", "Pujara"];
  const allPlayers = [...T20players, ...RanjiTrophyPlayers]; // merge using ES6 spread

  return (
    <div>
      <h2>Odd Team Players</h2>
      <ul>
        {oddTeam.map((p, index) => <li key={index}>{p}</li>)}
      </ul>

      <h2>Even Team Players</h2>
      <ul>
        {evenTeam.map((p, index) => <li key={index}>{p}</li>)}
      </ul>

      <h2>Merged Players</h2>
      <ul>
        {allPlayers.map((p, index) => <li key={index}>{p}</li>)}
      </ul>
    </div>
  );
};

export default IndianPlayers;
