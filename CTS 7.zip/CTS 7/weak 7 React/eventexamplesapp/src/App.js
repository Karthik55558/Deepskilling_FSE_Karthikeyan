import React, { Component } from "react";

class App extends Component {
  constructor() {
    super();
    this.state = {
      count: 0,
      message: "",
      rupees: "",
      euros: ""
    };
  }

  // Method 1: Increment counter
  increment = () => {
    this.setState({ count: this.state.count + 1 });
  };

  // Method 2: Say Hello
  sayHello = () => {
    this.setState({ message: "Hello! This is a static message." });
  };

  // Method 3: Decrement counter
  decrement = () => {
    this.setState({ count: this.state.count - 1 });
  };

  // Method 4: Button with argument
  sayWelcome = (word) => {
    this.setState({ message: `Welcome! You clicked: ${word}` });
  };

  // Synthetic event
  handleSyntheticEvent = (e) => {
    e.preventDefault();
    this.setState({ message: "I was clicked" });
  };

  // Currency Converter handler
  handleRupeesChange = (e) => {
    this.setState({ rupees: e.target.value });
  };

  handleSubmit = () => {
    const euro = parseFloat(this.state.rupees) / 90;
    this.setState({ euros: euro.toFixed(2) });
  };

  render() {
    return (
      <div style={{ padding: "30px", fontFamily: "Arial" }}>
        <h1>React Events Example App</h1>

        <h2>Counter: {this.state.count}</h2>
        <button onClick={() => { this.increment(); this.sayHello(); }}>
          Increment & Say Hello
        </button>{" "}
        <button onClick={this.decrement}>Decrement</button>

        <h3>{this.state.message}</h3>

        <button onClick={() => this.sayWelcome("welcome")}>Say Welcome</button>

        <br /><br />
        <button onClick={this.handleSyntheticEvent}>Click Me (Synthetic Event)</button>

        <br /><br />
        <h2>Currency Converter: Rupees to Euro</h2>
        <input
          type="number"
          value={this.state.rupees}
          onChange={this.handleRupeesChange}
          placeholder="Enter amount in ₹"
        />
        <button onClick={this.handleSubmit}>Convert</button>

        {this.state.euros && (
          <h3>Converted Amount: €{this.state.euros}</h3>
        )}
      </div>
    );
  }
}

export default App;
